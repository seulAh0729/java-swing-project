package db_p;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JTable;

class Message{
   String to_id;
   String from_id;
   String content;
   String maketime;
   
   public Message(String to_id, String from_id, String content, String maketime) {
      super();
      this.to_id = to_id;
      this.from_id = from_id;
      this.content = content;
      this.maketime = maketime;
   }
   
  String [] getarray(int set) {
	  if(set==1) {
		  return new String[] {from_id,content,maketime};
	  }else {
		  return new String[] {to_id,content,maketime};	  
	  }
  }
   
   

   
   
   
}

public class MessageDB {
	

   
   static final String host ="localhost";
   					//���� �޼�����
   static String[][] getTO_MESSAGE(String userID){
      
      
      ArrayList<Message> notices = new ArrayList<Message>();
      
      Connection con = null;
      Statement stmt=null;
      ResultSet rs =null;
      String [][] to_array=null;
      
      
      try {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         
         con = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":1521:xe", "HR", "HR");
         
         stmt = con.createStatement();
         
         rs = stmt.executeQuery("select * from MESSAGE where to_id = '"+userID+"' ORDER BY MAKETIME ASC");
         
         while (rs.next()) {
            String to_id = rs.getString("to_id");
            String from_id = rs.getString("from_id");
            String content = rs.getString("content");
            String maketime = rs.getString("maketime");
            
            
            
            notices.add(new Message(to_id, from_id, content, maketime));
         }
         
         if(!notices.isEmpty()) {
         to_array = new String[notices.size()][];
         for (int i = 0; i < notices.size(); i++) {
        	 to_array[i] = notices.get(i).getarray(1);
         }
         }
      
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            rs.close();
            stmt.close();
            con.close();
         } catch (Exception e2) {
            e2.printStackTrace();
         }
      }
   
      return to_array;
   }
   					//���� �޼�����
static String[][] getFROM_MESSAGE(String userID){
      
      
      ArrayList<Message> notices = new ArrayList<Message>();
      
      Connection con = null;
      Statement stmt=null;
      ResultSet rs =null;
      String [][] to_array=null;
      
      try {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         
         con = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":1521:xe", "HR", "HR");
         
         stmt = con.createStatement();
         
         rs = stmt.executeQuery("select * from MESSAGE where from_id = '"+userID+"' ORDER BY MAKETIME ASC");
         
         while (rs.next()) {
            String to_id = rs.getString("to_id");
            String from_id = rs.getString("from_id");
            String content = rs.getString("content");
            String maketime = rs.getString("maketime");
            
            
            
            notices.add(new Message(to_id, from_id, content, maketime));
         }
         if(!notices.isEmpty()) {
         to_array = new String[notices.size()][];
         for (int i = 0; i < notices.size(); i++) {
        	 to_array[i] = notices.get(i).getarray(0);
         }
         }
      
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            rs.close();
            stmt.close();
            con.close();
         } catch (Exception e2) {
            e2.printStackTrace();
         }
      }
   
      return to_array;
   }
   
   							//�޴� ���(admin)	 ������� (��)			����
   static boolean saveMESSAGE(String to_id, String from_id, String contant) { //�޼���������
      boolean res = false;
      
      Connection con = null;
      Statement stmt=null;
      
      
      try {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         
         con = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":1521:xe", "HR", "HR");
         
         stmt = con.createStatement();
         
         stmt.executeUpdate("INSERT INTO MESSAGE (TO_ID, FROM_ID, CONTENT, MAKETIME) VALUES ('"+to_id+"', '"+from_id+"', '"+contant+"', TO_DATE(sysdate, 'YYYY-MM-DD HH24:MI:SS'))");
         System.out.println("����");
         res = true;
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            stmt.close();
            con.close();
         } catch (Exception e2) {
            e2.printStackTrace();
         }
      }
      
      return res;
      
      
   }
   
   
   static boolean deleteSendMESSAGE(String userID) { //�����޼����� ����
	      boolean res = false;
	      
	      Connection con = null;
	      Statement stmt=null;
	      
	      
	      try {
	         Class.forName("oracle.jdbc.driver.OracleDriver");
	         
	         con = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":1521:xe", "HR", "HR");
	         
	         stmt = con.createStatement();
	         
	         stmt.executeUpdate("delete from message where from_id = '"+userID+"'");
	         System.out.println("����");
	         res = true;
	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            stmt.close();
	            con.close();
	         } catch (Exception e2) {
	            e2.printStackTrace();
	         }
	      }
	      
	      return res;
	      
	      
	   }
   
   
   static boolean deleteGiveMESSAGE(String userID) { //�޴� �޼����� ����
	      boolean res = false;
	      
	      Connection con = null;
	      Statement stmt=null;
	      
	      
	      try {
	         Class.forName("oracle.jdbc.driver.OracleDriver");
	         
	         con = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":1521:xe", "HR", "HR");
	         
	         stmt = con.createStatement();
	         
	         stmt.executeUpdate("delete from message where to_id = '"+userID+"'");
	         System.out.println("����");
	         res = true;
	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            stmt.close();
	            con.close();
	         } catch (Exception e2) {
	            e2.printStackTrace();
	         }
	      }
	      
	      return res;
	      
	      
	   }

   
   

   public static void main(String[] args) {
	   
   }

}